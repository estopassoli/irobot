const help = (prefix) => {
	return `

 🤖 *iRobot Menu* 🤖

➸ Prefixo:  *「${prefix} 」*
_O prefixo é um *caractere* que define as palavras em comandos_

     
       🤖 *FIGURINHAS* 🤖

*${prefix}figurinha* ou *${prefix}sticker*
_converte imagem/gif em adesivo_

*${prefix}toimg*
_converte adesivo em imagem_

       🤖 *OUTROS* 🤖

 *${prefix}ocr*
_copia o texto de uma foto e lhe envia_

*${prefix}setprefix*
_alterar o prefixo do bot_
nota: somente pode ser usado pelo proprietário do bot no caso o *Erick*

*${prefix}blocklist*
_lista de numeros bloqueados pelo bot_



      🤖 *GRUPO* 🤖
      
 *${prefix}linkgroup*
_envia o link do grupo_

 *${prefix}marcar*
_marca todos os membros do grupo, incluindo administradores_
nota: você precisa ser administrador do grupo

*${prefix}simi*
_ativa o modo Simi no grupo, é como se fosse um narrador_
uso : *${prefix}simi 1* para ativar o modo simi e *${prefix}simi 0* para desativar o modo Simi
*nota: você precisa ser administrador do grupo*

*${prefix}add*
_adicionar membro ao grupo_
como usar: *${prefix}add 5585xxxxx*
nota: o bot precisa ser admin!

*${prefix}kick*
_remove membros do grupo_
como usar: *${prefix}kick e o @da pessoa*
nota: você precisa ser admin e o bot também

*${prefix}promote*
_torna um membro do grupo em administrador
como usar: *${prefix}promote e o @da pessoa*
nota: você precisa ser admin e o bot também

*${prefix}demote*
_torna um administrador em membro comum
como usar: *${prefix}demote e o @da pessoa*
nota: você precisa ser admin e o bot também

*${prefix}listadmin*
_comando para listar os cornos do grupo_

*${prefix}welcome*
_quando alguém entrar no grupo o bot dá as boas vindas_

╔════════════════════
  coded by *Riquie*
  Contato 👇
  wa.me/5513996597134
╚════════════════════`
}

exports.help = help






