const help = (prefix) => {
	return `

  🤖 *iRobot* 🤖

_FIGURINHAS_
      
➸ Comando : *${prefix}sticker* ou *${prefix}stiker*
➸ útil em : converter imagem/gif/vídeo em adesivo
➸ uso : responder imagem/gif/video ou enviar imagem/gif/video com legenda\n
 

_OUTROS_

➸ Comando : *${prefix}toimg*
➸ útil em : converter adesivo em imagem
➸ uso : adesivo de resposta\n

➸ Comando : *${prefix}ocr*
➸ útil em : pegar o texto da foto e lhe enviar
➸ uso : responder imagem ou enviar mensagem com legenda\n


➸ Comando : *${prefix}setprefix*
➸ útil em : alterar o prefixo do bot
➸ uso : *${prefix}setprefix [texto|opcional]*\nexemplo : *${prefix}setprefix ?*
➸ Nota : Usado somente pelo proprietário do bot\n

_GRUPO_
      
➸ Comando : *${prefix}linkgroup*
➸ útil em : enviar o link do grupo
➸ uso : basta enviar o comando\n

➸ Comando : *${prefix}marcar*
➸ útil em : marcar todos os membros do grupo, incluindo administradores
➸ uso : basta enviar o comando\n
➸ Nota : Você precisa ser administrador do grupo\n

➸ Comando : *${prefix}add*
➸ útil em : adicionar membro ao grupo
➸ uso : *${prefix}add +55(13) 98854-7251*\n
➸ Nota : o bot precisa ser admin!\n

➸ Comando : *${prefix}kick*
➸ útil em : remover membros do grupo
➸ uso : *${prefix}kick e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também

➸ Comando : *${prefix}promote*
➸ útil em : tornar membro do grupo um administrador
➸ uso : *${prefix}promote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também

➸ Comando : *${prefix}demote*
➸ útil em : tornar o administrador um membro comum
➸ uso : *${prefix}demote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também.   

╔════════════════════
  Créditos: *Riquie*
  DUVIDAS? 👇
  WA.me/5513996597134
╚════════════════════`
}

exports.help = help




